"""zinnia_bootstrap"""
__version__ = '0.4'
__license__ = 'BSD License'

__author__ = 'Fantomas42'
__email__ = 'fantomas42@gmail.com'

__url__ = 'https://github.com/Fantomas42/zinnia-theme-bootstrap'
